//
//  HomeViewController.swift
//  SoftwareApp
//
//  Created by M_AMBIN02648 on 01/02/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var helloLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
