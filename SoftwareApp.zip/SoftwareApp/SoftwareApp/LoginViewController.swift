//
//  LoginViewController.swift
//  SoftwareApp
//
//  Created by M_AMBIN02648 on 01/02/23.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var emailLbl: UITextField!
    
    @IBOutlet weak var pswdLbl: UITextField!
    
    @IBAction func Login(_ sender: UIButton) {
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

  

}
